import React from 'react';
import CategoriesPage from "@/components/templates/CategoriesPage/CategoriesPage";

const Categories = () => {
	return (
		<>
			<CategoriesPage/>
		</>
	);
};

export default Categories;
