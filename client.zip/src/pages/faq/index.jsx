import React from 'react';

const Index = () => {
	return (
		<div>
			FAq
		</div>
	);
};

export default Index;
