import React from 'react';

const Index = () => {
	return (
		<div>
			About biba
		</div>
	);
};

export default Index;
