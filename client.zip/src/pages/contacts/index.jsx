import React from 'react';

const Index = () => {
	return (
		<div>
			contactss
		</div>
	);
};

export default Index;
