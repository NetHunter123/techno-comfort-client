import React from 'react';
import AuthPage from "@/components/templates/AuthPage/AuthPage";

const Index = () => {

  return (
    <main
      className={``}
    >
      <AuthPage/>
    </main>
  );
};

export default Index;
