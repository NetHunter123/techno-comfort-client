import React from 'react';

const DeliveryPayment = () => {
	return (
		<div>
			dellivery-payment
		</div>
	);
};

export default DeliveryPayment;
