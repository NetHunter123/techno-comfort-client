import {combine, createDomain, createEvent, createStore} from "effector";

const user = createDomain()
// Події для зміни стану користувача
export const setUser = user.createEvent();
export const clearUser = user.createEvent();

// Стан користувача
export const $userStore = user.createStore(null)
	.on(setUser, (_, user) => user)
	.reset(clearUser);
