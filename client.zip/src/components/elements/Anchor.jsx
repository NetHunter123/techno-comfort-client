import React from 'react';

const Anchor = ({id}) => {
	return (
		<a id={id} className="anchor"/>
	);
};

export default Anchor;
