import React from 'react';
import styles from './auth.module.css';
import {Avatar, Button, Menu} from "@mantine/core";
import {PiSignIn} from "react-icons/pi";
import {SlLogin} from "react-icons/sl";
import Link from "next/link";
import {useUnit} from "effector-react";
import {$userStore} from "@/context/user";
import {FaRegTrashCan} from "react-icons/fa6";
import {CiLogout} from "react-icons/ci";
import {useMediaQuery} from "@/hooks/useMediaQuery";

const AuthBtn = () => {
	const isMedia567 = useMediaQuery(567)
	
	const user = useUnit($userStore);
	
	console.log("user",user)
	return (<>{!user ?
		<Button
			component={Link}
			href="/auth"
			className={styles.signin__button}
			variant="light"
			color="var(--m-accent-400)"
			rightSection={<SlLogin size={"18px"}/>}
			aria-label="sign-in"
		>
			Вхід
		</Button> :
		<Menu shadow="md" width={200} position="right-start">
			<Menu.Target>
				<Avatar className={styles.account__avatar} radius="xl" >AV</Avatar>
				{/*<Button*/}
				{/*	className={styles.signin__button}*/}
				{/*	variant="light"*/}
				{/*	color="var(--m-accent-400)"*/}
				{/*	rightSection={<SlLogin size={"18px"}/>}*/}
				{/*	aria-label="sign-in"*/}
				{/*>*/}
				{/*	Вхід*/}
				{/*</Button>*/}
			</Menu.Target>
			
			<Menu.Dropdown>
				<Menu.Label>Application</Menu.Label>
				
				<Menu.Item
					color="red"
					leftSection={<CiLogout  size="18px"/>}
				>
					Вийти з акаунту
				</Menu.Item>
			</Menu.Dropdown>
		</Menu>}
	</>);
};

export default AuthBtn;
